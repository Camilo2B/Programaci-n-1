package co.edu.uniquindio.poo;

public class Bibliotecario extends Persona {
    private double salario;
    private int prestamosRealizados;
    private int añosAntiguedad;

    public Bibliotecario(String nombre, String cedula, String telefono, String correo, double salario, int aniosAntiguedad) {
        super(nombre, cedula, telefono, correo);
        this.salario = salario;
        this.añosAntiguedad = aniosAntiguedad;
        this.prestamosRealizados = 0;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public int getPrestamosRealizados() {
        return prestamosRealizados;
    }

    public void incrementarPrestamos() {
        this.prestamosRealizados++;
    }

    public int getAñosAntiguedad() {
        return añosAntiguedad;
    }

    public void setAñosAntiguedad(int aniosAntiguedad) {
        this.añosAntiguedad = aniosAntiguedad;
    }

    public double calcularPagoTotal() {
        double pagoBase = prestamosRealizados * 0.2;
        double bonificacion = pagoBase * (0.02 * añosAntiguedad);
        return salario + pagoBase + bonificacion;
    }

    @Override
    public String toString() {
        return getNombre() + " (" + getCedula() + ")";
    }
}